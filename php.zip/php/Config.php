<?php 
	define('DB_USERNAME','id17148266_root');
	define('DB_PASSWORD','Diff_android288');
	define('DB_NAME','id17148266_chat');
	define('DB_HOST','localhost');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAATS3ycKE:APA91bEBgBR5F7h03viWQJct28uBsjSpCUhQkPevqyyWWRbe4XMS-7mWC4oMbKBIEhGLLthPallwPWI5CqzVcWkzLsBayWCn2IBQ0VviyvKSJkodYnqliZO6t33RPz5M9hnJnNHAY20O');

	